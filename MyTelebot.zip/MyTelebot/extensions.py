import requests
import json

keys = {
    'рубль': 'RUB',
    'доллар': 'USD',
    'евро': 'EUR',
}

# Базовый класс исключений для этого проекта
class APIException(Exception):
     pass

# Класс преобразования валют
class GetPrice:
    @staticmethod
    def get_price(base: str, quote: str, amount: float):

        quote_ticker = keys[quote]
        base_ticker = keys[base]

        r = requests.get(f'https://min-api.cryptocompare.com/data/price?fsym={quote_ticker}&tsyms={base_ticker}')
        total_base = json.loads(r.content)[keys[base]] * amount


        return total_base
