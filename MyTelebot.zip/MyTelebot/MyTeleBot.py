import telebot
import re

from BotApiToken import *
from extensions import *

bot = telebot.TeleBot(API_TOKEN)

@bot.message_handler(commands=['start', 'help'])
def help(message: telebot.types.Message):
    text = 'Введите команду боту в следующем формате:\n<имя валюты> \
    <в какую валюту перевести> \
    <количество переводимой валюты>\nСписок всех вводимых валют: /values'
    bot.reply_to(message, text)

@bot.message_handler(commands=['values'])
def values(message: telebot.types.Message):
    text = 'Доступные валюты:'
    for key in keys.keys():
        text = '\n'.join((text, key))
    bot.reply_to(message, text)

@bot.message_handler(content_types=['text', ])
def convert(message: telebot.types.Message):
    ErrType = 'пользовательская', 'системная'
    try:
        str = message.text
        #Устраняем возможные пробелы в начале и в конце строки
        str = str.strip()
        #Устраняем возможные пробелы между словами
        str = re.sub(r"\s+", " ", str)

        #Складываем элементы строки сообщения в массив
        values = str.split(' ')

        if len(values) > 3:
            raise APIException('Слишком много параметров.', ErrType[0], 'MoreLenError')

        if len(values) < 3:
            raise APIException('Слишком мало параметров.', ErrType[0], 'LessLenError')

        #Разбираем массив на фрагменты
        quote, base, amount = values

        #Обработка собственных и перехват внутренних ошибок
        if quote == base:
            raise APIException(f'Запрещен перевод одинаковой валюты: <{base}>.', ErrType[0], 'CurTypeError')

        try:
            dummy_ticker = keys[quote]
        except KeyError:
            raise APIException(f'Не удалось обработать валюту: <{quote}>.', ErrType[1], 'KeyError')

        try:
            dummy_ticker = keys[base]
        except KeyError:
            raise APIException(f'Не удалось обработать валюту: <{base}>.', ErrType[1], 'KeyError')

        try:
            amount = float(amount)
        except ValueError:
            raise APIException(f'Не удалось обработать количество: <{amount}>.', ErrType[1], 'ValueError')

        if amount <= 0:
            raise APIException('Количество должно быть положительным числом.', ErrType[0], 'SignAmountError')

        #Преобразование курсов валют
        total_base = GetPrice.get_price(base, quote, amount)

    except APIException as e:
        #Обработка ошибки пользователя
        text = f'{e.args[0]} \nТип ошибки: <{e.args[2]}> ({e.args[1]}).'
        bot.send_message(message.chat.id, text)
    else:
        #Если нет ошибок
        text = f'Цена {amount} {quote} в {base} - {total_base:.2f}'
        bot.send_message(message.chat.id, text)

bot.infinity_polling()







